﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace varoatælling
{
    [Serializable]
    public class Bistade : INotifyPropertyChanged
    {
        public List<varoa> varoaTællinger;


   
        public Bistade()
        {
            varoaTællinger = new List<varoa>();
        }

        public string name;

        public Bistade(string aName)
        {

            name = aName;

        }

        public List<varoa> VAROATÆLLINGER 
        {
            get
            {
                return varoaTællinger;
            }
            set
            {
                varoaTællinger = value;
            }
        }


        public string NAME
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public void addToList(varoa varoa)
        {
            varoaTællinger.Add(varoa);

        }

        #region INotifyPropertyChanged implementation

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }

        }

        #endregion

    }

}
