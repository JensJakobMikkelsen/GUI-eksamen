﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

using System.Windows.Input;
using System.Windows;
using System.Xml.Serialization;
using System.IO;
using System.Windows.Media;
using System.Windows.Data;
using MvvmFoundation.Wpf;

namespace varoatælling
{
    public class mainViewModel : ObservableCollection<Bistade>, INotifyPropertyChanged
    {

        public static List<Bistade> temp = new List<Bistade>();

        public List<Bistade> VAROATÆLLINGER
        {
            get
            {
                return temp;
            }
            set
            {
                temp = value;
            }
        }

    

        public mainViewModel()
        {

            if ((bool)(DesignerProperties.IsInDesignModeProperty.GetMetadata(typeof(DependencyObject)).DefaultValue))
            {

            }

        }

        #region Commands

        ICommand _addCommand;
        public ICommand AddCommand
        {
            get { return _addCommand ?? (_addCommand = new RelayCommand(AddBistade)); }
        }

        public void AddBistade()
        {
            // Show Modal Dialog
            var dlg = new bistadeWindow();
            dlg.Title = "Add new bistade";
            Bistade newBistade = new Bistade();
            dlg.DataContext = newBistade;

            if (dlg.ShowDialog() == true)
            {
                
                const int cprLength = 18;

                // Check length
                if (newBistade.name.Length <= cprLength)
                {
                    Add(newBistade);

                    CurrentBistade = newBistade;
                    temp.Add(currentBistade);

                }
                
            }
        }

        ICommand _varoaAdd;
        public ICommand VaroaAdd
        {
            get { return _varoaAdd ?? (_addCommand = new RelayCommand(AddVaroa)); }
        }

        public void AddVaroa()
        {
            // Show Modal Dialog
            var dlg = new varoaWindow();
            dlg.Title = "Add new bistade";
            varoa newVaroa = new varoa();
            dlg.DataContext = newVaroa;

            if (dlg.ShowDialog() == true)
            {

                clock clk1 = new clock();
                newVaroa.date = clk1.Date;
                this.ElementAt(CurrentIndex).addToList(newVaroa);
            
                //temp[currentIndex].addToList(newVaroa);
            }
        }


        ICommand _nextCommand;
        public ICommand NextCommand
        {
            get
            {

                return _nextCommand ?? (_nextCommand = new RelayCommand(
                    () => ++CurrentIndex,
                    () => CurrentIndex < (Count - 1)));
            }
        }

        ICommand _PreviusCommand;
        public ICommand PreviusCommand
        {
            get { return _PreviusCommand ?? (_PreviusCommand = new RelayCommand(PreviusCommandExecute, PreviusCommandCanExecute)); }
        }

        private void PreviusCommandExecute()
        {
            if (CurrentIndex > 0)
            {
               
                --CurrentIndex;
            }

        }

        private bool PreviusCommandCanExecute()
        {
            if (CurrentIndex > 0)
                return true;
            else
                return false;
        }

        #region Properties

        Bistade currentBistade = null;

        public Bistade CurrentBistade
        {
            get { return currentBistade; }
            set
            {
                if (currentBistade != value)
                {
                    currentBistade = value;
                    NotifyPropertyChanged();
                }
            }
        }

        static int currentIndex = -1;

        public int CurrentIndex
        {
            get { return currentIndex; }
            set
            {
                if (currentIndex != value)
                {
                    currentIndex = value;
                    NotifyPropertyChanged();
                }
            }
        }

        #endregion



        public IReadOnlyCollection<string> FilterBistader
        {
            get
            {
                ObservableCollection<string> result = new ObservableCollection<string>();
                result.Add("All");
                foreach (var s in new Listed_Questions())
                    result.Add(s);
                return result;
            }
        }



        #endregion

        #region INotifyPropertyChanged implementation

        public new event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion
    }
}
