﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace varoatælling
{
    public class Listed_Questions : ObservableCollection<string>
    {
        public Listed_Questions()
        {
            Add("What is 6 times...");
            Add("WILL WORLD EXPLODE????");
            Add("WHO YOU PUNY HUMAN??!?!");
            Add("NEJ");
            Add("ØV");
        }
    }
}
