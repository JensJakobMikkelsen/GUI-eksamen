﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace varoatælling
{
    [Serializable]
    public class varoa : INotifyPropertyChanged
    {
        public varoa()
        {

        }

        public string amount;
        public string date;
        public string bemærkning;

        public varoa(string aAmount, string aDate, string aBemærkning)
        {

            amount = aAmount;
            date = aDate;
            bemærkning = aBemærkning;

        }


        public string AMOUNT
        {
            get
            {
                return amount;
            }
            set
            {
                amount = value;
            }
        }

        public string DATE
        {
            get
            {
                return date;
            }
            set
            {
                date = value;
            }
        }


        public string BEMÆRKNING
        {
            get
            {
                return bemærkning;
            }
            set
            {
                bemærkning = value;
            }
        }



        #region INotifyPropertyChanged implementation

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }

        }

        #endregion

    }
}
